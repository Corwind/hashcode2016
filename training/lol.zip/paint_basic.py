#!/usr/bin/python3

import sys
from poney import parse

def paint_lol(m):
    l = []
    for i in range(len(m)):
        for j in range(len(m[0])):
            if m[i][j] == '#':
                l.append('PAINT_SQUARE {} {} 0\n'.format(i, j))
    with open('lol.submit', 'w') as o:
        o.write('{}\n'.format(len(l)))
        o.writelines(l)

if __name__ == "__main__":
    paint_lol(parse(sys.argv[1]))
